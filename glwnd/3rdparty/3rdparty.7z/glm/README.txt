GLM-0.9.9.4 (32-bit & 64-bit)

Include
  $(CppLibraries)\OpenGL\GLM\include

Library
  $(CppLibraries)\OpenGL\GLM\lib\$(Platform)\$(Configuration)

Binary
  PATH=%PATH%;$(CppLibraries)\OpenGL\GLM\bin\$(Platform)\$(Configuration)