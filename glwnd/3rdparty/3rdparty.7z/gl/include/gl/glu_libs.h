/**
 * GLU - Unversioned
 */

#pragma once

/**
 * Library Files
 */

#pragma comment(lib, "glu32.lib")