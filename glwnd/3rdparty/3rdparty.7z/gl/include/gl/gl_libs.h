/**
 * OpenGL - Unversioned
 */

#pragma once

/**
 * Library Files
 */

#pragma comment(lib, "opengl32.lib")